(function(){
  const body = document.body;
  const key = 'mkmkoop_theme';
  const saved = localStorage.getItem(key) || 'dark';
  if(saved === 'light') body.classList.add('light');
  const toggle = document.getElementById('themeToggle');
  if(toggle){
    toggle.addEventListener('click', () => {
      body.classList.toggle('light');
      localStorage.setItem(key, body.classList.contains('light') ? 'light' : 'dark');
    });
  }

  function formatCountdown(ms){
    const abs = Math.abs(ms);
    const d = Math.floor(abs / (1000*60*60*24));
    const h = Math.floor(abs / (1000*60*60)) % 24;
    const m = Math.floor(abs / (1000*60)) % 60;
    const s = Math.floor(abs / 1000) % 60;
    return `${d}天 ${h}时 ${m}分 ${s}秒`;
  }

  function updateCountdowns(){
    document.querySelectorAll('.task-card[data-deadline]').forEach(card => {
      const deadline = card.getAttribute('data-deadline');
      const label = card.querySelector('.countdown');
      if(!deadline || !label) return;
      const diff = new Date(deadline).getTime() - Date.now();
      label.textContent = diff >= 0 ? `剩余 ${formatCountdown(diff)}` : `已超时 ${formatCountdown(diff)}`;
    });
  }

  updateCountdowns();
  setInterval(updateCountdowns, 1000);
})();
